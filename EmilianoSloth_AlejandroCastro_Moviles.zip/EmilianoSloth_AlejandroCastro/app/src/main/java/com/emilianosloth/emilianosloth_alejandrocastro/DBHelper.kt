package com.emilianosloth.emilianosloth_alejandrocastro

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.Year

class DBHelper(context: Context?): SQLiteOpenHelper(context, DB_FILE, null, 1) {



    override fun onCreate(db: SQLiteDatabase?) {
        val query = "CREATE TABLE $TABLE(" +
                "$COLUMN_ID INTEGER PRIMARY KEY, " +
                "$COLUMN_MODEL TEXT, " +
                "$COLUMN_YEAR INTEGER)"

        db?.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        val query = "DROP TABLE IF EXISTS ?"
        val args = arrayOf(TABLE)
        db?.execSQL(query, args)
        onCreate(db)
    }

    fun save(model: String, year: Int){
        val values = ContentValues();
        values.put(COLUMN_MODEL, model)
        values.put(COLUMN_YEAR, year)
        writableDatabase.insert(TABLE, null, values)
    }

    fun search(year: Int): ArrayList<String>{
        val clause = "$COLUMN_YEAR = ?"
        val args = arrayOf(year.toString())

        val cursor = readableDatabase.query(TABLE, null, clause, args, null, null, null)

        val list = arrayListOf<String>()

        if(cursor.moveToFirst()){
            list.add(cursor.getString(0))
            list.add(cursor.getString(1))
            list.add(cursor.getString(2))
        }

        while(cursor.moveToNext()){
            list.add(cursor.getString(0))
            list.add(cursor.getString(1))
            list.add(cursor.getString(2))
        }

        return list
    }

    fun getFirst(): ArrayList<String>{

        val cursor = readableDatabase.query(TABLE, null, null, null, null, null, null)

        val list = arrayListOf<String>()

        if(cursor.moveToFirst()){
            list.add(cursor.getString(0))
            list.add(cursor.getString(1))
            list.add(cursor.getString(2))
        }

        return list
    }

    companion object{
        private const val DB_FILE = "CARS.db"
        private const val TABLE = "CARS"
        private const val COLUMN_ID = "id"
        private const val COLUMN_MODEL = "model"
        private const val COLUMN_YEAR = "year"

    }

}