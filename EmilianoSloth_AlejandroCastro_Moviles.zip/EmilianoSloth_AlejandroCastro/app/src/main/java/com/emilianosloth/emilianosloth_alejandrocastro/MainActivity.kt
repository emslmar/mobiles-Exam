package com.emilianosloth.emilianosloth_alejandrocastro

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : AppCompatActivity() {
    lateinit var editText: EditText
    lateinit var button: Button

    val activityResultDB = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            result ->
        // always do this
        if(result.resultCode == Activity.RESULT_OK){
            // if everything was ok retrieve intent
            val data : Intent? = result.data
            Toast.makeText(this, "El id resultante es: " + data?.getStringExtra("result"), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.mainET)
        button = findViewById(R.id.mainButton)

        button.setOnClickListener {
            val intent = Intent(this, DBActivity::class.java)
            intent.putExtra("Message", editText.text.toString())
            activityResultDB.launch(intent)
        }

    }
}