package com.emilianosloth.emilianosloth_alejandrocastro

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class DBActivity : AppCompatActivity() {

    lateinit var messageET: TextView
    lateinit var idET: EditText
    lateinit var modelET: EditText
    lateinit var yearET: EditText
    lateinit var cleanBT : Button
    lateinit var saveBT : Button
    lateinit var searchBT : Button
    lateinit var returnBT : Button
    lateinit var nextBT : Button
    lateinit var previousBT : Button
    lateinit var db: DBHelper


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dbactivity)

        messageET = findViewById(R.id.dbTV)
        idET = findViewById(R.id.dbIdET)
        modelET = findViewById(R.id.dbModelET)
        yearET = findViewById(R.id.dbYearTE)
        cleanBT = findViewById(R.id.dbCleanBT)
        saveBT = findViewById(R.id.dbSaveNewBT)
        searchBT = findViewById(R.id.dbSearchBT)
        returnBT = findViewById(R.id.dbReturnBT)
        nextBT = findViewById(R.id.dbNextBT)
        previousBT = findViewById(R.id.dbPreviousBT)
        db = DBHelper(this)
        var currentResult = 0


        messageET.setText(intent.getStringExtra("Message"))

        var resultList = db.getFirst()
        if(!resultList.isEmpty()){
            idET.setText(resultList.get(0))
            modelET.setText(resultList.get(1))
            yearET.setText(resultList.get(2))
        }


        cleanBT.setOnClickListener {
            idET.setText("")
            modelET.setText("")
            yearET.setText("")
        }

        saveBT.setOnClickListener {
            db.save(modelET.text.toString(), Integer.parseInt(yearET.text.toString()))
        }

        searchBT.setOnClickListener {
            currentResult = 0;
            resultList = db.search(Integer.parseInt(yearET.text.toString()))
            if(resultList.get(0) == ""){
                Toast.makeText(this, "No Result", Toast.LENGTH_SHORT).show()
            }else{
                idET.setText(resultList.get(0))
                modelET.setText(resultList.get(1))
                yearET.setText(resultList.get(2))
            }
        }

        nextBT.setOnClickListener {
            currentResult++;
            if(resultList.size/3 > currentResult){
                idET.setText(resultList.get(currentResult*3))
                modelET.setText(resultList.get(currentResult*3+1))
                yearET.setText(resultList.get(currentResult*3+2))
            }else{
                currentResult = resultList.size/3 -1
            }


        }

        previousBT.setOnClickListener {
            currentResult--
            if(currentResult>=0){
                idET.setText(resultList.get(currentResult*3))
                modelET.setText(resultList.get(currentResult*3+1))
                yearET.setText(resultList.get(currentResult*3+2))
            }else{
                currentResult = 0
            }

        }

        returnBT.setOnClickListener {
            val intent = Intent()
            intent.putExtra("result", idET.text.toString())
            setResult(Activity.RESULT_OK, intent)
            finish()
        }

    }
}